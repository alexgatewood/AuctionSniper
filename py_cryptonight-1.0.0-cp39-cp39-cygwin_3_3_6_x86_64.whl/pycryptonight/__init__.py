from _pycryptonight import cn_fast_hash, cn_slow_hash

